<?php
class Order_item  {
	public $id;
	public $order_id;
	public $product_id;
	public $quantity;
}