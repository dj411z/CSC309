<?php
class Final_order  {
	public $order_id;
	public $first;
	public $last;
	public $email;
	public $creditcard_number;
	public $creditcard_month;
	public $creditcard_year;
	public $order_date;
	public $order_time;
	public $total;
}