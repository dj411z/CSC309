<?php
class Customer  {
	public $id;
	public $first;
	public $last;
	public $login;
	public $password;
	public $email;	
}