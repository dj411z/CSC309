<?php
class ShoppingCart  {
	public $number;
	public $customer_id;
	public $items = array();
	public $total;	
}