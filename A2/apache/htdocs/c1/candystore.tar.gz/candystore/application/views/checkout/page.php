<?php 
	echo "<p>" . anchor('checkout_controller/newForm','Checkout Form') . "</p>";
	echo "<p>" . anchor('checkout_controller/checkout','Checkout For Real') . "</p>";
	echo "<p>" . anchor('email_controller/showAll','Send Email') . "</p>";
?>