<?php
 echo anchor('shopping_cart/showAll','My Cart') . "<br />";
 echo anchor('main/showAll','Candystore') . "<br />";
 echo anchor('main/index','Logout') . "<br />";
 ?>
