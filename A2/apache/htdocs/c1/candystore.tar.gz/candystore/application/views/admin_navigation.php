<?php
	 echo anchor('admin_customers/showAll', 'Customers') . "<br />";
	 echo anchor('admin_orders/showAll','Orders') . "<br />";
	 echo anchor('admin_products/showAll','Products') . "<br />";
	 echo anchor('main/index','Logout') . "<br />";
 ?>